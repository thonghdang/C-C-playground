/* Author: Thong Dang
 * CS 250 - Project 2
 * This is the header file */


/* Some function prototypes. */
void make_dict(char *);
void spell_check(char *);
unsigned int distance (const char *, const char *);
